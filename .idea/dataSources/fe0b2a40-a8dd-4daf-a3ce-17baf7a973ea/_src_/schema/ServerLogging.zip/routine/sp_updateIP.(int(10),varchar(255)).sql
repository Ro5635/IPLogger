CREATE PROCEDURE sp_updateIP(IN p_id INT(10), IN p_IPAddress VARCHAR(255))
  BEGIN
        
        UPDATE Servers SET ipaddress = p_IPAddress WHERE id= p_id ; 


END;
